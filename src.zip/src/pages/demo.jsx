import React, { useState } from 'react'

export default function DemoExam() {
    const q = [
        {
            id: "wb1",
            quetion: "waht is redux?",
            option: ["fun", "foo", "bar", "nahh"],
            answer: "fun"
        },
        {
            id: "wb2",
            quetion: "waht is html?",
            option: ["hypertext transfer protocol", "hypertext markup lang", "javascript", "none of above"],
            answer: "hypertext markup lang"
        },
        {
            id: "wb3",
            quetion: "waht is css?",
            option: ["sass", "less", "cascade style sheets", , "none of above"],
            answer: "cascade style sheets"
        },

    ]
    const [selectedQuetionIndex, setselectedQuetionIndex] = useState(0)
    // const ans = []
    const [ans, setans] = useState([])
    const handelchange = e => {
        // console.log(e.target.value);
        // ans.push({ ...q[0], uanswer: e.target.value })
        // console.log(ans);
        const result = ans.findIndex(item => item.id === q[selectedQuetionIndex].id)
        // console.log(result);
        if (result !== -1) {
            console.log("not inserted", result);
            const copy = [...ans]
            copy[result].uanswer = e.target.value
            setans(copy)
            // console.log(ans);
        } else {
            setans([...ans, { ...q[selectedQuetionIndex], uanswer: e.target.value }])
            // ans.push({ ...q[selectedQuetionIndex], uanswer: e.target.value })
            // console.log(ans);
        }
    }

    const handleChecked = item => {
        const found = ans && ans.findIndex(item => item.id === q[selectedQuetionIndex].id)
        console.warn(found);
        if (found >= 0 && item === ans[found].uanswer) {
            return true
        } else {
            return false
        }
    }
    const calculateResult = () => {
        const result = ans.filter(item => item.answer === item.uanswer)
        alert(result.length)

    }
    const handelNext = () => {
        setselectedQuetionIndex(selectedQuetionIndex + 1)
    }
    const handelpre = () => {
        setselectedQuetionIndex(selectedQuetionIndex - 1)
    }
    return (
        <>
            <pre>
                {JSON.stringify(ans, null, 2)}
            </pre>
            <div className="container">
                <h1>{q[selectedQuetionIndex].quetion}</h1>
                {q[selectedQuetionIndex].option.map(item => <div>
                    <input
                        onChange={handelchange}
                        value={item}
                        checked={handleChecked(item)}
                        type="radio" id={item} name={q[selectedQuetionIndex].id} />
                    <label htmlFor={item}>{item}</label>
                </div>)}
            </div>
            <button
                onClick={handelpre}
                type="button" class="btn btn-primary">prev</button>
            <button
                onClick={handelNext}
                type="button" class="btn btn-primary">Next</button>

            <button
                onClick={calculateResult}
                className='btn btn-primary w-100 mt-3'>Submit Answer</button>
        </>

    )
}