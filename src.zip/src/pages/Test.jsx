import React, { useState, useEffect } from 'react'
const q = [
    {
        id: "wb1",
        quetion: "waht is redux?",
        option: ["fun", "foo", "bar", "nahh"],
        answer: "fun"
    },
    {
        id: "wb2",
        quetion: "waht is html?",
        option: ["hypertext transfer protocol", "hypertext markup lang", "javascript", "none of above"],
        answer: "hypertext markup lang"
    },
    {
        id: "wb3",
        quetion: "waht is css?",
        option: ["sass", "less", "cascade style sheets", , "none of above"],
        answer: "cascade style sheets"
    },

]
export default function Test() {
    const [percent, setpercent] = useState(0)
    const [selectedQuetion, setselectedQuetion] = useState(0)
    const local = localStorage.getItem("timeout")  
        ? JSON.parse(localStorage.getItem("timeout"))
        : 10
    const [countdown, setcountdown] = useState(local)
    useEffect(() => {
        setpercent(((selectedQuetion + 1) / (q.length / 100)))
    }, [selectedQuetion])

    useEffect(() => {
        const interval = setInterval(() => {
            setcountdown(pre => {

                if (pre <= 0) {
                    localStorage.removeItem("timeout")
                    clearInterval(interval)
                    return 0
                } else {
                    localStorage.setItem("timeout", pre - 1)
                    return pre - 1
                }
            })
        }, 1000)
    }, [])

    return <div className='container'>
        {countdown <= 0 ? <h1>End Exam</h1> : <>
            <h1>{Math.floor(countdown / 60)} : {countdown % 60}</h1>
            <div class="progress mt-2">
                <div class={`progress-bar progress-bar-striped progress-bar-animated  
            ${percent < 50 ? " bg-danger" : " bg-success"}`} style={
                        { width: `${percent}%` }
                    } >
                    Progress {selectedQuetion + 1} / {q.length}
                </div>
            </div>
            <div class="card">
                <div class="card-header">{q[selectedQuetion].quetion}</div>
                <div class="card-body">
                    <div className="row">
                        {
                            q[selectedQuetion].option.map((item, index) => <div className="col-6 ">
                                <input
                                    type="radio"
                                    name={q[selectedQuetion].id}
                                    id={q[selectedQuetion].id + index}
                                    className='form-check-input' />
                                <label
                                    className='form-check-label ms-2'
                                    htmlFor={q[selectedQuetion].id + index}>
                                    {item}
                                </label>
                            </div>

                            )
                        }

                    </div>
                </div>
                <div class="card-footer">
                    {
                        selectedQuetion !== 0 && <button
                            onClick={e => setselectedQuetion(selectedQuetion - 1)}>
                            pre
                        </button>
                    }

                    {
                        selectedQuetion !== q.length - 1 && <button
                            onClick={e => setselectedQuetion(selectedQuetion + 1)}>
                            Next
                        </button>
                    }

                </div>
            </div>
        </>
        }
    </div>

}