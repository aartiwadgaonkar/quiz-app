import React from 'react'
import DemoExam from './pages/demo'
import Exam from './pages/Exam'
import Test from './pages/Test'

export default function App() {
  return (
    <>
      {/* <div>App</div> */}
      {/* <Exam /> */}
      {/* <Test/> */}
      <DemoExam />
    </>

  )
}
